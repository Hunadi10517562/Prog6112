/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class PatientIT {
    
    public PatientIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getId method, of class Patient.
     */
    @org.junit.Test
    public void testGetId() {
        System.out.println("getId");
        Patient instance = null;
        String expResult = "";
        String result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFirstName method, of class Patient.
     */
    @org.junit.Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Patient instance = null;
        String expResult = "";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLastName method, of class Patient.
     */
    @org.junit.Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Patient instance = null;
        String expResult = "";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAge method, of class Patient.
     */
    @org.junit.Test
    public void testGetAge() {
        System.out.println("getAge");
        Patient instance = null;
        int expResult = 0;
        int result = instance.getAge();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getGender method, of class Patient.
     */
    @org.junit.Test
    public void testGetGender() {
        System.out.println("getGender");
        Patient instance = null;
        String expResult = "";
        String result = instance.getGender();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCondition method, of class Patient.
     */
    @org.junit.Test
    public void testGetCondition() {
        System.out.println("getCondition");
        Patient instance = null;
        String expResult = "";
        String result = instance.getCondition();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCategory method, of class Patient.
     */
    @org.junit.Test
    public void testGetCategory() {
        System.out.println("getCategory");
        Patient instance = null;
        PatientCategory expResult = null;
        PatientCategory result = instance.getCategory();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFirstName method, of class Patient.
     */
    @org.junit.Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String name = "";
        Patient instance = null;
        instance.setFirstName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLastName method, of class Patient.
     */
    @org.junit.Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String name = "";
        Patient instance = null;
        instance.setLastName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAge method, of class Patient.
     */
    @org.junit.Test
    public void testSetAge() {
        System.out.println("setAge");
        int age = 0;
        Patient instance = null;
        instance.setAge(age);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setGender method, of class Patient.
     */
    @org.junit.Test
    public void testSetGender() {
        System.out.println("setGender");
        String gender = "";
        Patient instance = null;
        instance.setGender(gender);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCondition method, of class Patient.
     */
    @org.junit.Test
    public void testSetCondition() {
        System.out.println("setCondition");
        String condition = "";
        Patient instance = null;
        instance.setCondition(condition);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of display method, of class Patient.
     */
    @org.junit.Test
    public void testDisplay() {
        System.out.println("display");
        Patient instance = null;
        instance.display();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
