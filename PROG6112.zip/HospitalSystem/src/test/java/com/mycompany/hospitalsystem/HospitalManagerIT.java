/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class HospitalManagerIT {
    
    public HospitalManagerIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getPatientsList method, of class HospitalManager.
     */
    @org.junit.Test
    public void testGetPatientsList() {
        System.out.println("getPatientsList");
        HospitalManager instance = new HospitalManager();
        ArrayList<Patient> expResult = null;
        ArrayList<Patient> result = instance.getPatientsList();
        assertEquals(expResult, result);
        //
    }

    /**
     * Test of register method, of class HospitalManager.
     */
    @org.junit.Test
    public void testRegister() {
        System.out.println("register");
        Patient patient = null;
        HospitalManager instance = new HospitalManager();
        boolean expResult = false;
        boolean result = instance.register(patient);
        assertEquals(expResult, result);
        // 
        
    }

    /**
     * Test of search method, of class HospitalManager.
     */
    @org.junit.Test
    public void testSearch() {
        System.out.println("search");
        String id = "";
        HospitalManager instance = new HospitalManager();
        Patient expResult = null;
        Patient result = instance.search(id);
        assertEquals(expResult, result);
        // 
    }

    /**
     * Test of update method, of class HospitalManager.
     */
    @org.junit.Test
    public void testUpdate() {
        System.out.println("update");
        String id = "";
        String firstName = "";
        String lastName = "";
        int age = 0;
        String gender = "";
        String condition = "";
        HospitalManager instance = new HospitalManager();
        boolean expResult = false;
        boolean result = instance.update(id, firstName, lastName, age, gender, condition);
        assertEquals(expResult, result);
        // 
    }

    /**
     * Test of delete method, of class HospitalManager.
     */
    @org.junit.Test
    public void testDelete() {
        System.out.println("delete");
        String id = "";
        HospitalManager instance = new HospitalManager();
        boolean expResult = false;
        boolean result = instance.delete(id);
        assertEquals(expResult, result);
        // 
    }

    /**
     * Test of allocateBed method, of class HospitalManager.
     */
    @org.junit.Test
    public void testAllocateBed() {
        System.out.println("allocateBed");
        String patientId = "";
        String bed = "";
        HospitalManager instance = new HospitalManager();
        boolean expResult = false;
        boolean result = instance.allocateBed(patientId, bed);
        assertEquals(expResult, result);
        //
    }

    /**
     * Test of releaseBed method, of class HospitalManager.
     */
    @org.junit.Test
    public void testReleaseBed() {
        System.out.println("releaseBed");
        String bed = "";
        HospitalManager instance = new HospitalManager();
        boolean expResult = false;
        boolean result = instance.releaseBed(bed);
        assertEquals(expResult, result);
        // 
    }

    /**
     * Test of displayWard method, of class HospitalManager.
     */
    @org.junit.Test
    public void testDisplayWard() {
        System.out.println("displayWard");
        HospitalManager instance = new HospitalManager();
        instance.displayWard();
        // 
    }

    /**
     * Test of availableBeds method, of class HospitalManager.
     */
    @org.junit.Test
    public void testAvailableBeds() {
        System.out.println("availableBeds");
        HospitalManager instance = new HospitalManager();
        instance.availableBeds();
        // 
    }

    /**
     * Test of occupiedBeds method, of class HospitalManager.
     */
    @org.junit.Test
    public void testOccupiedBeds() {
        System.out.println("occupiedBeds");
        HospitalManager instance = new HospitalManager();
        instance.occupiedBeds();
        //  
    }

    /**
     * Test of report method, of class HospitalManager.
     */
    @org.junit.Test
    public void testReport() {
        System.out.println("report");
        HospitalManager instance = new HospitalManager();
        instance.report();
        //
    }

    /**
     * Test of getPatients method, of class HospitalManager.
     */
    @org.junit.Test
    public void testGetPatients() {
        System.out.println("getPatients");
        boolean surname = false;
        HospitalManager instance = new HospitalManager();
        ArrayList<Patient> expResult = null;
        ArrayList<Patient> result = instance.getPatients(surname);
        assertEquals(expResult, result);
        //
    }
    
}
