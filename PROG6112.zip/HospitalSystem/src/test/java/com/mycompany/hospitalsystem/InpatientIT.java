/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class InpatientIT {
    
    public InpatientIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getBed method, of class Inpatient.
     */
    @org.junit.Test
    public void testGetBed() {
        System.out.println("getBed");
        Inpatient instance = null;
        String expResult = "";
        String result = instance.getBed();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setBed method, of class Inpatient.
     */
    @org.junit.Test
    public void testSetBed() {
        System.out.println("setBed");
        String bed = "";
        Inpatient instance = null;
        instance.setBed(bed);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of display method, of class Inpatient.
     */
    @org.junit.Test
    public void testDisplay() {
        System.out.println("display");
        Inpatient instance = null;
        instance.display();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
