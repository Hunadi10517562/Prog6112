/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Admin
 */
@org.junit.runner.RunWith(Suiteorg.junit.runners.Suite.class)
@org.junit.runners.Suite.SuiteClasses({PatientCategoryIT.class, PatientIT.class, InpatientIT.class, HospitalManagerIT.class, HospitalSystemIT.class})
public class HospitalsystemITSuite {

    @org.junit.BeforeClass
    public static void setUpClass() throws Exception {
    }

    @org.junit.AfterClass
    public static void tearDownClass() throws Exception {
    }

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }
    
}
