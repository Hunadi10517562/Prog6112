/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class HospitalSystemIT {
    
    public HospitalSystemIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        HospitalSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of patientMenu method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testPatientMenu() {
        System.out.println("patientMenu");
        HospitalSystem.patientMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerPatient method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testRegisterPatient() {
        System.out.println("registerPatient");
        HospitalSystem.registerPatient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchPatient method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testSearchPatient() {
        System.out.println("searchPatient");
        HospitalSystem.searchPatient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updatePatient method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testUpdatePatient() {
        System.out.println("updatePatient");
        HospitalSystem.updatePatient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletePatient method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testDeletePatient() {
        System.out.println("deletePatient");
        HospitalSystem.deletePatient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayPatients method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testDisplayPatients() {
        System.out.println("displayPatients");
        HospitalSystem.displayPatients();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bedMenu method, of class HospitalSystem.
     */
    @org.junit.Test
    public void testBedMenu() {
        System.out.println("bedMenu");
        HospitalSystem.bedMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
