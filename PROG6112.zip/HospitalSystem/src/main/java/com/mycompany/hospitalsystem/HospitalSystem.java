package com.mycompany.hospitalsystem;
/**
 * @author Hunadi
 */
import java.util.ArrayList;
import java.util.Scanner;

// Categories for Patients
enum PatientCategory {
    INPATIENT, OUTPATIENT, EMERGENCY
}

// Main Parent patient class
class Patient {
    private String id, firstName, lastName, gender, condition;
    private int age;
    private PatientCategory category;

    public Patient(String id, String firstName, String lastName, int age,
                   String gender, String condition, PatientCategory category) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.condition = condition;
        this.category = category;
    }

    public String getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getCondition() { return condition; }
    public PatientCategory getCategory() { return category; }

    public void setFirstName(String name) { firstName = name; }
    public void setLastName(String name) { lastName = name; }
    public void setAge(int age) { this.age = age; }
    public void setGender(String gender) { this.gender = gender; }
    public void setCondition(String condition) { this.condition = condition; }

    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Condition: " + condition);
        System.out.println("Category: " + category);
    }
}

// Inpatient inherits from Patient
class Inpatient extends Patient {
    private String ward;
    private String bed;

    public Inpatient(String id, String firstName, String lastName, int age,
                     String gender, String condition, String ward) {
        super(id, firstName, lastName, age, gender, condition,
              PatientCategory.INPATIENT);
        this.ward = ward;
        bed = null;
    }

    public String getBed() { return bed; }
    public void setBed(String bed) { this.bed = bed; }

    @Override
    public void display() {
        super.display();
        System.out.println("Ward: " + ward);
        System.out.println("Bed: " + (bed == null ? "Unassigned" : bed));
    }
}

// Patient and Bed manager
class HospitalManager {
    private ArrayList<Patient> patients = new ArrayList<>();
    private String[][] beds = new String[4][5];

    public ArrayList<Patient> getPatientsList() {
        return patients;
    }

    // Registers the patient
    public boolean register(Patient patient) {
        if (search(patient.getId()) != null) return false;
        patients.add(patient);
        return true;
    }

    // Search the patient by their ID
    public Patient search(String id) {
        for (Patient p : patients) {
            if (p.getId().equalsIgnoreCase(id)) return p;
        }
        return null;
    }

    // Update patient details
    public boolean update(String id, String firstName, String lastName,
                          int age, String gender, String condition) {
        Patient p = search(id);
        if (p == null) return false;

        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setCondition(condition);
        return true;
    }

    // Delete the patient with bed they're placed in
    public boolean delete(String id) {
        Patient p = search(id);
        if (p == null) return false;

        if (p instanceof Inpatient) {
            Inpatient in = (Inpatient) p;
            if (in.getBed() != null) releaseBed(in.getBed());
        }

        patients.remove(p);
        return true;
    }

    // Helper: Converts bed ID (B01-B20) into row and column indices
    private int[] getBedCoordinates(String bed) {
        try {
            if (bed == null || !bed.toUpperCase().startsWith("B")) return null;
            int number = Integer.parseInt(bed.substring(1));
            if (number < 1 || number > 20) return null;
            
            int index = number - 1;
            int row = index / 5;
            int col = index % 5;
            return new int[]{row, col};
        } catch (Exception e) {
            return null;
        }
    }

    // Allocates the bed to inpatient
    public boolean allocateBed(String patientId, String bed) {
        Patient p = search(patientId);

        if (!(p instanceof Inpatient)) return false;

        Inpatient in = (Inpatient) p;

        if (in.getBed() != null) return false;

        int[] coords = getBedCoordinates(bed);
        if (coords == null || beds[coords[0]][coords[1]] != null) return false;

        beds[coords[0]][coords[1]] = patientId;
        in.setBed(bed);
        return true;
    }

    // Releases the beds
    public boolean releaseBed(String bed) {
        int[] coords = getBedCoordinates(bed);

        if (coords == null || beds[coords[0]][coords[1]] == null) return false;

        Patient p = search(beds[coords[0]][coords[1]]);

        if (p instanceof Inpatient) {
            ((Inpatient) p).setBed(null);
        }

        beds[coords[0]][coords[1]] = null;
        return true;
    }

    public void displayWard() {
        System.out.println(" WARD LAYOUT ");

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 5; col++) {
                int bedNum = (row * 5) + col + 1;
                String bedCode = String.format("B%02d", bedNum);
                String occupant = beds[row][col];

                if (occupant == null)
                    System.out.print(bedCode + "[FREE]   ");
                else
                    System.out.print(bedCode + "[" + occupant + "]   ");
            }
            System.out.println();
        }
    }

    // Shows available beds 
    public void availableBeds() {
        System.out.print("Available Beds: ");

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 5; col++) {
          
                if (beds[row][col] == null) {
                    int bedNum = (row * 5) + col + 1;
                    System.out.print(String.format("B%02d ", bedNum));
                }
            }
        }
        System.out.println();
    }

    // Show occupied beds
    public void occupiedBeds() {
        System.out.print("Occupied Beds: ");

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 5; col++) {
                if (beds[row][col] != null) {
                    int bedNum = (row * 5) + col + 1;
                    System.out.print(String.format("B%02d(%s) ", bedNum, beds[row][col]));
                }
            }
        }
        System.out.println();
    }

    public void report() {
        int occupied = 0;

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 5; col++) {
                if (beds[row][col] != null) occupied++;
            }
        }

        int available = 20 - occupied;
        double rate = (occupied / 20.0) * 100;

        System.out.println(" WARD REPORT ");
        System.out.println("Registered Patients: " + patients.size());
        System.out.println("Occupied Beds: " + occupied + "/20");
        System.out.println("Available Beds: " + available);
        System.out.printf("Occupancy Rate: %.2f%%\n", rate);
    }

    // Arranges patients by id and surname
    public ArrayList<Patient> getPatients(boolean surname) {
        ArrayList<Patient> list = new ArrayList<>(patients);

        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = 0; j < list.size() - 1 - i; j++) {

                String a = surname
                        ? list.get(j).getLastName()
                        : list.get(j).getId();

                String b = surname
                        ? list.get(j + 1).getLastName()
                        : list.get(j + 1).getId();

                if (a.compareToIgnoreCase(b) > 0) {
                    Patient temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                }
            }
        }

        return list;
    }
}

// Main code
public class HospitalSystem {

    static Scanner input = new Scanner(System.in);
    static HospitalManager manager = new HospitalManager();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            System.out.println("HOSPITAL SYSTEM ");
            System.out.println("1. Patient Management");
            System.out.println("2. Bed Management");
            System.out.println("3. Reports");
            System.out.println("4. Exit");
            System.out.print("Choose: ");

            String choice = input.nextLine();

            switch (choice) {
                case "1": patientMenu(); break;
                case "2": bedMenu(); break;
                case "3": manager.report(); break;
                case "4": running = false; break;
                default: System.out.println("Invalid choice.");
            }
        }

        System.out.println("Thank you for using our Hospital System.");
    }

    // Menu for patients
    public static void patientMenu() {
        System.out.println(" PATIENT MANAGEMENT ");
        System.out.println("1. Register");
        System.out.println("2. Search");
        System.out.println("3. Update");
        System.out.println("4. Delete");
        System.out.println("5. Display All");
        System.out.print("Choose: ");

        String choice = input.nextLine();

        switch (choice) {
            case "1": registerPatient(); break;
            case "2": searchPatient(); break;
            case "3": updatePatient(); break;
            case "4": deletePatient(); break;
            case "5": displayPatients(); break;
            default: System.out.println("Invalid choice.");
        }
    }

    // Registering a patient
    public static void registerPatient() {
        System.out.println("REGISTER PATIENT");

        System.out.print("Patient ID: ");
        String id = input.nextLine();

        System.out.print("First Name: ");
        String first = input.nextLine();

        System.out.print("Last Name: ");
        String last = input.nextLine();

        System.out.print("Age: ");
        int age = Integer.parseInt(input.nextLine());

        System.out.print("Gender: ");
        String gender = input.nextLine();

        System.out.print("Medical Condition: ");
        String condition = input.nextLine();

        System.out.println("1. Inpatient");
        System.out.println("2. Outpatient");
        System.out.println("3. Emergency");
        System.out.print("Category: ");

        int type = Integer.parseInt(input.nextLine());

        Patient patient;

        if (type == 1) {
            patient = new Inpatient(
                id, first, last, age, gender, condition, "W1"
            );
        } else if (type == 2) {
            patient = new Patient(
                id, first, last, age, gender, condition,
                PatientCategory.OUTPATIENT
            );
        } else if (type == 3) {
            patient = new Patient(
                id, first, last, age, gender, condition,
                PatientCategory.EMERGENCY
            );
        } else {
            System.out.println("Invalid category.");
            return;
        }

        if (manager.register(patient))
            System.out.println("Patient registered successfully.");
        else
            System.out.println("Patient ID already exists.");
    }

    // Search for patient
    public static void searchPatient() {
        System.out.print("Enter Patient ID: ");
        Patient p = manager.search(input.nextLine());

        if (p != null)
            p.display();
        else
            System.out.println("Patient not found.");
    }

    // Update patient details
    public static void updatePatient() {
        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        System.out.print("New First Name: ");
        String first = input.nextLine();

        System.out.print("New Last Name: ");
        String last = input.nextLine();

        System.out.print("New Age: ");
        int age = Integer.parseInt(input.nextLine());

        System.out.print("New Gender: ");
        String gender = input.nextLine();

        System.out.print("New Condition: ");
        String condition = input.nextLine();

        if (manager.update(id, first, last, age, gender, condition))
            System.out.println("Patient updated.");
        else
            System.out.println("Patient not found.");
    }

    // Delete patient details
    public static void deletePatient() {
        System.out.print("Enter Patient ID: ");

        if (manager.delete(input.nextLine()))
            System.out.println("Patient deleted.");
        else
            System.out.println("Patient not found.");
    }

    // Display patients stored
    public static void displayPatients() {
        System.out.println("1. Sort by ID");
        System.out.println("2. Sort by Surname");
        System.out.print("Choose: ");

        boolean surname = input.nextLine().equals("2");

        ArrayList<Patient> list = manager.getPatients(surname);

        if (list.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }

        for (Patient p : list)
            p.display();
    }

    // Menu for bed management
    public static void bedMenu() {
        System.out.println(" BED MANAGEMENT");
        System.out.println("1. Allocate Bed");
        System.out.println("2. Release Bed");
        System.out.println("3. View Ward");
        System.out.println("4. Available Beds");
        System.out.println("5. Occupied Beds");
        System.out.print("Choose: ");

        String choice = input.nextLine();

        switch (choice) {
            case "1":
                System.out.print("Patient ID: ");
                String id = input.nextLine();

                System.out.print("Bed ID (B01-B20): ");
                String bed = input.nextLine();

                if (manager.allocateBed(id, bed))
                    System.out.println("Bed allocated.");
                else
                    System.out.println("Could not allocate bed.");
                break;

            case "2":
                System.out.print("Bed ID: ");

                if (manager.releaseBed(input.nextLine()))
                    System.out.println("Bed released.");
                else
                    System.out.println("Could not release bed.");
                break;

            case "3":
                manager.displayWard();
                break;

            case "4":
                manager.availableBeds();
                break;

            case "5":
                manager.occupiedBeds();
                break;

            default:
                System.out.println("Invalid choice.");
        }
    }
}